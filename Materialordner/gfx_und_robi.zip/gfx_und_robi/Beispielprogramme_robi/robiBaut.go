// Mit diesem Programm kann man schnell eine Welt neu zusammen
// bauen und abspeichern.
// Dazu muss nur der Dateiname für die Welt unten eingetragen werden.
package main

import . "robi"

func main () {
	WeltZoomen (150)
	Melden ("Habe gezoomt! - Jetzt kann gebaut werden!",0)
	Baumodus ()
	//WeltSpeichern("meineWelt.robi")
	Fertig ()
}

