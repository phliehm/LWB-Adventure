package main

import . "robi"

func main () {
	FehlerMelden ("Gleich wird eine Welt geladen!",0)
	WeltLaden ("gefaengnis.robi")
	FehlerMelden ("Die Welt wurde geladen!",0)
	Laufen1 ()
	RechtsDrehen ()
	Fertig ()
}

	
