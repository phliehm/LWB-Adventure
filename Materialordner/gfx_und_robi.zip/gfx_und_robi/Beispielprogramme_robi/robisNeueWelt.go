// Demonstration für das Skalieren der Robi-Welt.
// Natürlich können auch solche Welten gespeichert und geladen werden.
package main

import . "robi"

func main () {
	Melden("Standard aktiviert, versuche nun zu skalieren!",0)
	NeueWelt (800,600,100)
	Melden("Habe skaliert!!",0)
	LinksDrehen ()
	Mauern1 ()
	Mauern1 ()
	Legen1()
	Legen1()
	Fertig ()
}
