package main

import ( . "gfx" ; "fmt" )

func spieleLied() {
	SpieleNote ("4C",0.25,0.25)
	
	SpieleNote ("2C",1.5,0) // Linke Hand -> ohne Verzögerung zur nächsten Note
	SpieleNote ("4E",0.5,0.5)
	SpieleNote ("4E",0.25,0.25)
	
	SpieleNote ("4E",0.25,0.25)
	SpieleNote ("4D",0.25,0.25)
	SpieleNote ("4E",0.25,0.25)
	
	SpieleNote ("2F",0.75,0) // Linke Hand
	SpieleNote ("4F",0.75,0.75)
	
	SpieleNote ("2C",0.75,0) // Linke Hand
	SpieleNote ("4E",0.5,0.5)
	SpieleNote ("4E",0.25,0.25)
	
	SpieleNote ("2G",1.5,0)  // Linke Hand
	SpieleNote ("4D",0.5,0.5)
	SpieleNote ("4D",0.25,0.25)
	
	SpieleNote ("4D",0.25,0.25)
	SpieleNote ("4C",0.25,0.25)
	SpieleNote ("4D",0.25,0.25)
	
	SpieleNote ("2C",1.5,0)  //Linke Hand
	SpieleNote ("4E",0.75,0.75)
	
	SpieleNote ("4C",0.5,0.5)
	SpieleNote ("4C",0.25,0.25)
	
	SpieleNote ("4E",0.5,0.5)
	SpieleNote ("4E",0.25,0.25)
	
	SpieleNote ("4E",0.25,0.25)
	SpieleNote ("4D",0.25,0.25)
	SpieleNote ("4E",0.25,0.25)
	
	SpieleNote ("2F",1.5,0)  // Linke Hand
	SpieleNote ("4F",0.75,0.75)
	
	SpieleNote ("4A",0.5,0.5)
	SpieleNote ("4A",0.25,0.25)
	
	SpieleNote ("2C",0.75,0)   // Linke Hand
	SpieleNote ("4G",0.25,0.25)
	SpieleNote ("4A",0.25,0.25)
	SpieleNote ("4G",0.25,0.25)
	
	SpieleNote ("2G",0.75,0)   // Linke Hand
	SpieleNote ("4F",0.5,0.5)
	SpieleNote ("4D",0.25,0.25)
	
	SpieleNote ("2C",1.25,0)   // Linke Hand
	SpieleNote ("4C",1.25,1.25)	
}

func main () {
	Fenster(640,480)
	SetzeNotenTempo(200)
	fmt.Println ("Notentempo:", GibNotenTempo ())
	
	SetzeKlangparameter(44100,2,2,1,0.375)
	SetzeHuellkurve(0.002,0.75,0,0.006) //Klavier ???
	spieleLied ()	
	
	SetzeKlangparameter(44100,2,2,3,0.5) // Akkordeon ???
	SetzeHuellkurve(0.5,0.006,0.8,0.006)
	spieleLied ()
	
	SetzeKlangparameter(44100,2,2,2,0.5) // Zirkusorgel ???
	SetzeHuellkurve(0.002,0.006,1.0,0.006)
	spieleLied()
	
	SetzeKlangparameter(44100,2,2,2,0.5) // Flöte ???
	SetzeHuellkurve(0.20,0.114,4.0/15,0.006)
	spieleLied()
	
	SetzeKlangparameter(44100,2,2,3,0.5) // Gitarre ???
	SetzeHuellkurve(0.002,0.75,2.0/15,0.024)
	spieleLied()
	
	SetzeKlangparameter(44100,2,2,1,0.125) // Cembalo ???
	SetzeHuellkurve(0.002,0.75,0,0.006)
	spieleLied()

	SetzeKlangparameter(44100,2,2,1,0.5) // Orgel ???
	SetzeHuellkurve(0.002,0.75,0.6,0.006)
	spieleLied()

	SetzeKlangparameter(44100,2,2,1,0.25) // Trompete ???
	SetzeHuellkurve(0.1,0.75,4.0/15,0.024)
	spieleLied()

	SetzeKlangparameter(44100,2,2,2,0.125) // Xylophon ???
	SetzeHuellkurve(0.002,0.75,0,0)
	spieleLied()
	
}


