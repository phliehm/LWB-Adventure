package main

import . "gfx"

func main () {
	Fenster (640,480)
	Stiftfarbe (255,0,0)
	Vollkreis (40,40,39)
	Clipboard_kopieren (0,0,80,80)
	
	Stiftfarbe (200,200,200)
	Vollrechteck(0,100,640,380)
	
	for i:=uint8(0);i<=5;i++ {
		Transparenz (50*i)
		Clipboard_einfuegen(uint16(i)*100+10,200)
	}
	for i:=uint8(0);i<=5;i++ {
		Transparenz (50*i)
		Clipboard_einfuegenMitColorKey(uint16(i)*100+10,300,255,255,255)
	}
	TastaturLesen1 ()
}
