package main
// Autor: St. Schmidt
// Datum: 18.10.2020 ; letzte Änderung: 26.04.2021
// Zweck: Demo für "Sprites" und Transparenz mit dem Paket gfx in Go

import ( "gfx" ; "time" ; "math" ; "os" ; "runtime" ; "fmt" )

var fontpath string = os.Getenv("GOPATH")

type drache struct {
	x,y,w,v float64 // Mittelpunktskoordinaten, Winkel, Geschwindigkeit
	radius uint16   // Radius
}

func NewDrache (x,y,w,v float64, radius uint16) (*drache) {
	d:= new (drache)
	d.x, d.y, d.w, d.v = x, y, w, v
	d.radius = radius
	return d
}

func (d *drache) bewegen () {
	// Berechnung und Setzen der neuen Koordinaten
	if d.w>0 && d.w < 180 && d.y <= float64(d.radius)*2  { //Anstoß oben
		d.w =  360 - d.w
	}
	if (d.w>270 || d.w < 90) && d.x >= float64(gfx.Grafikspalten()-1) -float64(d.radius) { //Anstoß rechts
		d.w = (180 - d.w + 360 )
		if d.w >=360 { d.w = d.w - 360 }
	}
	if d.w>180 && d.w < 360 && d.y >= float64(gfx.Grafikzeilen()-1) - float64(d.radius)*2 { //Anstoß unten
		d.w = 360 - d.w
	}
	if d.w > 90 && d.w < 270 && d.x <= float64(d.radius) { //Anstoß links
		d.w = (180 - d.w + 360 ) 
		if d.w >=360 { d.w = d.w - 360 }
	}
	d.x = d.x + math.Cos (d.w * math.Pi/180)
	d.y = d.y - math.Sin (d.w * math.Pi/180)
}

func (d *drache) neuzeichnen () {
	gfx.Transparenz (0)
	gfx.LadeBildMitColorKey(uint16(d.x-float64(d.radius)),uint16(d.y-float64(d.radius)*2),"./Drache.bmp",255,255,255)
	gfx.Stiftfarbe (0,0,0)
	gfx.Linie (uint16(d.x),uint16(d.y),400,599)
}

func drachen_bewegen (d [](*drache)) {
	var y int16 = 50
	var dy int16 = 1
	for {
		gfx.LadeBildInsClipboard("./Drache.bmp") // Demo, dass es auch mit dem Clipboard geht
		//1. Schritt: neue Positionen der Drachen.
		for i:=0; i < len (d) ; i++ { d[i].bewegen () }
		//2. Schritt: Alles / Drachen darstellen
		gfx.UpdateAus ()
		gfx.Restaurieren(0,0,800,600)
		for i:=0; i < len (d) ; i++ { d[i].neuzeichnen () }
		// Clipboard auch darstellen - zur Demo (Inhalt ist ein weiterer Drache)
		gfx.Transparenz(0) // einstellbar :-)
		gfx.Clipboard_einfuegenMitColorKey(100,uint16(y),255,255,255)
		gfx.Stiftfarbe (255,0,0)
		gfx.Linie (150,uint16(y)+100,400,599)
		y = y + dy
		if y > 409 { dy = -1 }
		if y < 1 {dy = 1 }
		//Wolken mit Transparenz einblenden
		for i:=uint16(10);i<30;i++ {
			gfx.Stiftfarbe (255,255,255)
			gfx.Transparenz(190)
			gfx.Vollrechteck(0,50 +3*i,800,200-6*i)
			gfx.Transparenz(220)
			gfx.Vollrechteck(0,250+3*i,800,200-6*i)
		}
		gfx.UpdateAn ()
		//3.Schritt: Warten ...
		time.Sleep (time.Duration(1 * 5.0e6))
	} 
}

func main () {
	var d [](*drache)
	
	switch runtime.GOOS {
		case "linux": 
		if fontpath == "" { //wsl erkennt GOPATH nicht
			fontpath = "/home/lewein/go/"
		} 
		fontpath = fontpath + "/src/gfx/fonts/"
		case "windows":
		fontpath = os.Getenv("GOPATH")+"\\src\\gfx\\fonts\\"
		default:
		fmt.Println ("Betriebssystem nicht erkannt!")
	}
	//Fenster auf
	gfx.Fenster (800,600)   //NEU: Fenstergröße muss angegeben werden!!
	gfx.Fenstertitel("Wir lassen Drachen steigen!")
	gfx.Stiftfarbe (128,192,255)
	gfx.Vollrechteck(0,0,800,600)
	gfx.Stiftfarbe (0,0,0)
	gfx.Transparenz(0)
	gfx.Schreibe (300,500,"Hier fliegen Drachen!")
	gfx.SetzeFont (fontpath+"LiberationSerif-Regular.ttf", 30)
	gfx.SchreibeFont(300,520,"Durch den Nebel!")
	gfx.Archivieren()
	//Drachen erzeugen 
	d = append (d,NewDrache (300,300,10,20,50))
	d = append (d,NewDrache (300,300,50,20,50))
	d = append (d,NewDrache (300,300,70,20,50))
	d = append (d,NewDrache (300,300,100,20,50))
	d = append (d,NewDrache (300,300,130,20,50))
	d = append (d,NewDrache (300,300,150,20,50))
	//Drachen bewegen ...
	go drachen_bewegen (d)	
	//Haupprogramm wartet auf ENTER
	gfx.TastaturLesen1()
}
