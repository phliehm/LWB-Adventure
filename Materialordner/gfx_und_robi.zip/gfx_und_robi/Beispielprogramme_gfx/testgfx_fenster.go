package main

import ( "gfx" ; "time" )

func main () {
	for i:=0; i<3;i++ {
		gfx.Fenster(800,600)
		gfx.Linie (0,0,400,400)
		time.Sleep(1e9)
		gfx.FensterAus ()
		time.Sleep (1e9)
	}
}
